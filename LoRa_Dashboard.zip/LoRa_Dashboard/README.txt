LoRa Antenna Tracking Dashboard

Files:
- index.html: browser dashboard

How to run:
1. Upload your existing dummyreciver.ino firmware to the ESP32.
2. Disconnect Arduino IDE Serial Monitor / Serial Plotter. Only one program can normally own the ESP32 serial port at a time.
3. Keep the ESP32 connected by USB.
4. Put index.html in a folder and serve that folder on localhost. One easy method:
   - Install Python if needed.
   - Open a terminal in this folder.
   - Run: python -m http.server 8000
5. Open http://localhost:8000 in Google Chrome or Microsoft Edge on desktop.
6. Click "Connect ESP32", choose the ESP32 serial port, and allow access.
7. The page reads JSON telemetry at 115200 baud.

Important:
- The dashboard uses the existing JSON emitted by sendDashboardData() in dummyreciver.ino.
- It ignores ordinary human-readable Serial debug lines and only processes JSON objects where type is "telemetry".
- It does not send commands to the ESP32 and cannot move motors. It is a read-only monitor.
- Do not keep Arduino Serial Monitor open while the dashboard is connected.
- Web Serial requires a supported browser and a secure context (localhost or HTTPS).
- If the browser does not offer the ESP32 port, close other serial tools and reconnect the USB cable.
